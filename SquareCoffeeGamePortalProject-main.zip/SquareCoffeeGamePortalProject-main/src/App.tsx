import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { ProtectedRoute } from './components/ProtectedRoute'
import { LanguageSelector } from './components/LanguageSelector'
import { useAuth } from './components/AuthContext'

// Auth Components
import { Login } from './Authentification/Login'
import { SignUp } from './Authentification/SignUp'
import { ForgotPassword } from './Authentification/ForgotPassword'
import { PasswordReset } from './Authentification/PasswordReset'

// Example Internal Pages
const Dashboard = () => (
  <div className="auth-container">
    <h2>{/* t('dashboard') */}Dashboard</h2>
    <p>Welcome to your secure area.</p>
  </div>
)

function App() {
  const { user, loading } = useAuth();

  // Show nothing or a spinner while checking if the user is logged in
  if (loading) return <div className="spinner-container"><div className="spinner"></div></div>;

  return (
    <BrowserRouter>
      {/* Floating Language Switcher */}
      <div style={{ position: 'fixed', top: '20px', right: '20px', zIndex: 1000 }}>
        <LanguageSelector />
      </div>

      <Routes>
        {/* 1. THE ROOT: Login Page */}
        {/* If user is already logged in, redirect root to dashboard */}
        <Route 
          path="/" 
          element={user ? <Navigate to="/dashboard" replace /> : <Login />} 
        />

        {/* 2. PUBLIC AUTH ROUTES */}
        <Route path="/signup" element={<SignUp />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/password-reset" element={<PasswordReset />} />

        {/* 3. PROTECTED ROUTES (The Gatekeeper) */}
        <Route element={<ProtectedRoute />}>
          <Route path="/dashboard" element={<Dashboard />} />
          {/* Add more protected pages here like /profile or /settings */}
        </Route>

        {/* 4. FALLBACK: Send unknown links back to root */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App