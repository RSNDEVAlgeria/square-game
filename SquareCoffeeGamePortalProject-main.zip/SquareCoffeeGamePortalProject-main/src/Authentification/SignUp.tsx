import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useTranslation } from 'react-i18next';
import { useNavigate, Link } from 'react-router-dom';
import toast from 'react-hot-toast';

export const SignUp = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Logic Validation (C++/Java Style)
    if (formData.password.length < 8) {
      return toast.error(t('password_too_short')); // "Must be 8+ characters"
    }
    if (formData.password !== formData.confirmPassword) {
      return toast.error(t('passwords_do_not_match'));
    }

    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: formData.email,
      password: formData.password,
      options: {
        data: { full_name: formData.name }
      }
    });

    if (error) {
      toast.error(error.message);
    } else {
      toast.success(t('signup_success_check_email'));
      navigate('/login');
    }
    setLoading(false);
  };

  const handleGoogleAuth = async () => {
    const { error } = await supabase.auth.signInWithOAuth({ provider: 'google' });
    if (error) toast.error(error.message);
  };

  return (
    <div className="auth-container">
      <div className="security-badge">🛡️ {t('secure_registration')}</div>
      <h2 style={{ textAlign: 'center', marginBottom: '8px' }}>{t('create_account')}</h2>
      <p style={{ textAlign: 'center', color: 'var(--text-muted)', marginBottom: '24px' }}>
        {t('join_us_today')}
      </p>

      <button onClick={handleGoogleAuth} className="btn-main btn-google">
        <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" width="18" alt="G" />
        {t('signup_google')}
      </button>

      <form onSubmit={handleSignUp}>
        <div className="form-group">
          <label className="input-label">{t('full_name')}</label>
          <input 
            type="text" 
            placeholder="John Doe"
            onChange={e => setFormData({...formData, name: e.target.value})}
            required 
          />
        </div>

        <div className="form-group">
          <label className="input-label">{t('email')}</label>
          <input 
            type="email" 
            placeholder="email@example.com"
            onChange={e => setFormData({...formData, email: e.target.value})}
            required 
          />
        </div>

        <div className="form-group">
          <label className="input-label">{t('password')}</label>
          <div className="input-container">
            <input 
              type={showPass ? "text" : "password"} 
              className="input-with-icon"
              placeholder="••••••••"
              onChange={e => setFormData({...formData, password: e.target.value})}
              required 
            />
            <button 
              type="button" 
              className="password-toggle" 
              onClick={() => setShowPass(!showPass)}
            >
              {showPass ? '👁️' : '🙈'}
            </button>
          </div>
          <small style={{ color: 'var(--text-muted)', fontSize: '0.75rem' }}>{t('min_8_chars')}</small>
        </div>

        <div className="form-group">
          <label className="input-label">{t('confirm_password')}</label>
          <input 
            type="password" 
            placeholder="••••••••"
            onChange={e => setFormData({...formData, confirmPassword: e.target.value})}
            required 
          />
        </div>

        <button type="submit" disabled={loading} className="btn-main">
          {loading ? t('processing') : t('sign_up_button')}
        </button>
      </form>

      <p style={{ marginTop: '24px', textAlign: 'center', fontSize: '0.9rem' }}>
        {t('already_have_account')} <Link to="/login" style={{ color: 'var(--primary)', fontWeight: '600' }}>{t('sign_in')}</Link>
      </p>
    </div>
  );
};