import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useTranslation } from 'react-i18next';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';

export const ForgotPassword = () => {
  const { t } = useTranslation();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSent, setIsSent] = useState(false);

  const handleResetRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // redirectTo is where the user goes AFTER clicking the email link
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/password-reset`,
    });

    if (error) {
      toast.error(error.message);
    } else {
      toast.success(t('reset_email_sent'));
      setIsSent(true);
    }
    setLoading(false);
  };

  return (
    <div className="auth-container">
      <div className="security-badge">
        <span>🛡️</span> {t('secure_link_generation')}
      </div>

      <h2 style={{ textAlign: 'center', marginBottom: '12px' }}>{t('forgot_password_title')}</h2>
      
      {!isSent ? (
        <>
          <p style={{ textAlign: 'center', color: 'var(--text-muted)', marginBottom: '32px', fontSize: '0.95rem' }}>
            {t('forgot_password_instruction')}
          </p>

          <form onSubmit={handleResetRequest}>
            <div className="form-group">
              <label className="input-label">{t('email_label')}</label>
              <input 
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                placeholder="you@example.com" 
                required 
              />
            </div>

            <button type="submit" disabled={loading} className="btn-main">
              {loading ? t('sending') : t('send_reset_link')}
            </button>
          </form>
        </>
      ) : (
        <div style={{ textAlign: 'center', padding: '20px 0' }}>
          <div style={{ fontSize: '3rem', marginBottom: '16px' }}>📧</div>
          <p style={{ color: 'var(--text-main)', fontWeight: '600', marginBottom: '8px' }}>
            {t('check_your_inbox')}
          </p>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '24px' }}>
            {t('email_sent_to')} <strong>{email}</strong>
          </p>
          <button onClick={() => setIsSent(false)} className="btn-main btn-google">
            {t('try_different_email')}
          </button>
        </div>
      )}

      <div style={{ marginTop: '32px', textAlign: 'center', borderTop: '1px solid #eee', paddingTop: '20px' }}>
        <Link to="/login" style={{ color: 'var(--primary)', fontWeight: '600', textDecoration: 'none', fontSize: '0.9rem' }}>
          ← {t('back_to_login')}
        </Link>
      </div>
    </div>
  );
};