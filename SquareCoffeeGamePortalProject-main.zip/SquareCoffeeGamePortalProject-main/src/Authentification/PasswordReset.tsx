import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

export const PasswordReset = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  // Security check: If there's no session, they shouldn't be here
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (!data.session) {
        toast.error(t('invalid_reset_session'));
        navigate('/login');
      }
    });
  }, [navigate, t]);

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password.length < 8) {
      return toast.error(t('password_too_short'));
    }
    if (password !== confirmPassword) {
      return toast.error(t('passwords_do_not_match'));
    }

    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });

    if (error) {
      toast.error(error.message);
    } else {
      toast.success(t('password_updated_success'));
      navigate('/login');
    }
    setLoading(false);
  };

  return (
    <div className="auth-container">
      <div className="security-badge">🔑 {t('secure_password_update')}</div>
      <h2 style={{ textAlign: 'center' }}>{t('set_new_password')}</h2>
      <p style={{ textAlign: 'center', color: 'var(--text-muted)', marginBottom: '24px' }}>
        {t('enter_secure_password')}
      </p>

      <form onSubmit={handleUpdatePassword}>
        <div className="form-group">
          <label className="input-label">{t('new_password')}</label>
          <div className="input-container">
            <input 
              type={showPass ? "text" : "password"} 
              className="input-with-icon"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required 
            />
            <button 
              type="button" 
              className="password-toggle" 
              onClick={() => setShowPass(!showPass)}
            >
              {showPass ? '👁️' : '🙈'}
            </button>
          </div>
          <small style={{ color: 'var(--text-muted)' }}>{t('min_8_chars')}</small>
        </div>

        <div className="form-group">
          <label className="input-label">{t('confirm_new_password')}</label>
          <input 
            type="password" 
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            placeholder="••••••••"
            required 
          />
        </div>

        <button type="submit" disabled={loading} className="btn-main">
          {loading ? t('updating') : t('update_password')}
        </button>
      </form>
    </div>
  );
};