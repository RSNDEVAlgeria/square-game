import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useTranslation } from 'react-i18next';
import toast from 'react-hot-toast';

export const Login = () => {
  const { t } = useTranslation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) toast.error(error.message);
    else toast.success(t('login_success'));
    setLoading(false);
  };

  const signInWithGoogle = async () => {
    const { error } = await supabase.auth.signInWithOAuth({ provider: 'google' });
    if (error) toast.error(error.message);
  };

  return (
    <div className="auth-container">
      <div className="security-badge">
        <span>🔒</span> {t('secure_encryption_active')}
      </div>
      
      <h2 style={{ textAlign: 'center', marginBottom: '8px' }}>{t('welcome_back')}</h2>
      <p style={{ textAlign: 'center', color: 'var(--text-muted)', marginBottom: '32px' }}>
        {t('please_enter_details')}
      </p>

      <button onClick={signInWithGoogle} className="btn-main btn-google">
        <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" width="20" alt="G" />
        {t('sign_in_google')}
      </button>

      <form onSubmit={handleLogin}>
        <div className="form-group">
          <label className="input-label">{t('email_label')}</label>
          <input 
            type="email" 
            value={email} 
            onChange={(e) => setEmail(e.target.value)} 
            placeholder="name@company.com" 
            required 
          />
        </div>
        <div className="form-group">
          <label className="input-label">{t('password_label')}</label>
          <input 
            type="password" 
            value={password} 
            onChange={(e) => setPassword(e.target.value)} 
            placeholder="••••••••" 
            required 
          />
        </div>
        <button type="submit" disabled={loading} className="btn-main">
          {loading ? t('processing') : t('sign_in')}
        </button>
      </form>

      <p style={{ marginTop: '24px', textAlign: 'center', fontSize: '0.9rem' }}>
        {t('no_account')} <a href="/signup" style={{ color: 'var(--primary)', fontWeight: '600' }}>{t('sign_up')}</a>
      </p>
    </div>
  );
};