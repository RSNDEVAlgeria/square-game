import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      password_too_short: "Password must be at least 8 characters",
      passwords_do_not_match: "Passwords do not match",
      update_password: "Update Password",
      min_8_chars: "Minimum 8 characters required",
      secure_encryption_active: "Secure Encryption is Active",
      welcome_back: "Welcome Back",
      please_enter_details: "Please login",
      email_label: "Email",
      password_label: "Password",
      no_account: "You don't have an account?",
      sign_up: "Sign Up",
      sign_in_google: "Continue with Google",
      sign_in: "Sign In",
      secure_registration: "Secure Registration Active",
      processing: "Processing...",

      create_account: "Create Account",
      join_us_today: "Join our community today",
      already_have_account: "Already have an account?",

      // Form Labels & Placeholders
      full_name: "Full Name",
      email: "Email Address",
      password: "Password",
      confirm_password: "Confirm Password",

      // Buttons
      sign_up_button: "Create My Account",
      signup_google: "Continue with Google",
      signup_success_check_email: "Account created! Please check your email for confirmation.",
    }
  },
  fr: {
    translation: {
      password_too_short: "Le mot de passe doit comporter au moins 8 caractères",
      passwords_do_not_match: "Les mots de passe ne correspondent pas",
      update_password: "Mettre à jour le mot de passe",
      min_8_chars: "Minimum 8 caractères requis",
      secure_encryption_active: "Le chiffrement sécurisé est actif.",
      welcome_back: "Content de vous revoir",
      please_enter_details: "Veuillez vous connecter",
      email_label: "E-mail",
      password_label: "Mot de passe",
      no_account: "Vous n'avez pas de compte ?",
      sign_up: "S'inscrire",
      sign_in_google: "Continue with Google",
      sign_in: "Se connecter",
      secure_registration: "Enregistrement Sécurisé Actif",
      processing: "Traitement en cours...",

      create_account: "Créer un compte",
      join_us_today: "Rejoignez notre communauté aujourd'hui",
      already_have_account: "Vous avez déjà un compte ?",

      full_name: "Nom complet",
      email: "Adresse e-mail",
      password: "Mot de passe",
      confirm_password: "Confirmer le mot de passe",
      sign_up_button: "Créer mon compte",
      signup_google: "Continuer avec Google",
      signup_success_check_email: "Compte créé ! Vérifiez vos e-mails pour confirmer.",
    }
  },
  ar: {
    translation: {
      password_too_short: "يجب أن تكون كلمة المرور 8 أحرف على الأقل",
      passwords_do_not_match: "كلمات المرور غير متطابقة",
      update_password: "تحديث كلمة المرور",
      min_8_chars: "8 أحرف كحد أدنى مطلوب",
      secure_encryption_active: "التشفير الآمن مُفعّل",
      welcome_back: "مرحبًا بعودتك",
      please_enter_details: "الرجاء تسجيل الدخول",
      email_label: "بريد إلكتروني",
      password_label: "كلمة المرور",
      no_account: "ليس لديك حساب؟",
      sign_up: "إنشاء حساب",
      sign_in_google: "Continue with Google",
      sign_in: "تسجيل الدخول"

    }
  }
};

i18n.use(initReactI18next).init({
  resources,
  lng: 'en', // default
  interpolation: { escapeValue: false }
});

// Logic to change direction for Arabic
i18n.on('languageChanged', (lng) => {
  document.body.dir = lng === 'ar' ? 'rtl' : 'ltr';
});

export default i18n;