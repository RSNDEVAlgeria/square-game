import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'
// Importing i18n here ensures it's initialized before the app loads
import './i18n' 
import { AuthProvider } from './components/AuthContext'
import { Toaster } from 'react-hot-toast'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <AuthProvider>
      <Toaster position="top-right" reverseOrder={false} />
      <App />
    </AuthProvider>
  </React.StrictMode>,
)