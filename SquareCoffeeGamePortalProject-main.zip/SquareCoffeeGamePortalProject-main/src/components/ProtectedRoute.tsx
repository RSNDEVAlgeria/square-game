import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './AuthContext';

export const ProtectedRoute = () => {
  const { user, loading } = useAuth();

  if (loading) {
    // You can replace this with a nice spinner
    return (
      <div style={{ display: 'flex', justifyContent: 'center', marginTop: '50px' }}>
        <div className="spinner"></div> 
      </div>
    );
  }

  // If no user is found, redirect to login
  return user ? <Outlet /> : <Navigate to="/login" replace />;
};