import { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';

export const LanguageSelector = () => {
  const { i18n } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const languages = [
    { code: 'en', name: 'EN', flag: '🇺🇸', dir: 'ltr' },
    { code: 'fr', name: 'FR', flag: '🇫🇷', dir: 'ltr' },
    { code: 'ar', name: 'AR', flag: '🇩🇿', dir: 'rtl' }
  ];

  const current = languages.find(l => l.code === i18n.language) || languages[0];

  useEffect(() => {
    const close = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) setIsOpen(false);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  return (
    <div className="lang-selector-container" ref={dropdownRef} style={{ position: 'fixed', top: '15px', right: '15px', zIndex: 2000 }}>
      <button className="lang-trigger" onClick={() => setIsOpen(!isOpen)}>
        {current.flag} {current.name}
      </button>

      {isOpen && (
        <div className="lang-dropdown">
          {languages.map((lng) => (
            <button key={lng.code} className="lang-option" onClick={() => {
              i18n.changeLanguage(lng.code);
              setIsOpen(false);
            }}>
              {lng.flag} {lng.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};